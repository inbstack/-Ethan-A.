# TODO

## [x] Brand positioning and responsive hero
- The website is for Inbstack™ and uses the positioning “Start focused, Scale your outreach safely.” and “Enterprise-Grade LinkedIn Infrastructure for B2B Outbound Teams.”
- The hero features “Rent LinkedIn accounts. Scale your outreach safely.” and has a rental call to action.
- The landing page uses responsive layouts for desktop and mobile.

## [x] Core services and order details
- LinkedIn Rentals Service: simple monthly plans; “Start focused, Scale with confidence”; monthly subscriptions with verified proxy configurations and a 14-day replacement guarantee.
- Cold Email Infrastructure: standalone inbox packs; 3+ year old Microsoft inboxes are available in packs of 5, 10, or 20; customers can build their email stack without adding a LinkedIn rental plan.
- High-Trust LinkedIn Profiles: manually grown LinkedIn profiles built through patient, human-led activity—not shortcuts.
- Custom location-based orders: customers can provide a preferred country or region; support will confirm availability and requirements before they order.

## [x] Shared pricing tiers and values
- Use a consistent tiered presentation for all three core services.
- Cold Email Infrastructure packs: 5 Microsoft inboxes — $49/month; 10 inboxes — $89/month; 20 inboxes — $159/month.
- High-Trust LinkedIn Profiles tiers: 100+ connections, 300+ connections, and 500+ connections. The supplied reference shows these tiers but no monetary amounts.
- LinkedIn Rentals monthly plans: Launch — $149/month; Growth — $649/month; Agency — $1,199/month.

## [x] Homepage keywords
- The page at `/` has a meta keywords tag with 3–8 focused, highly relevant keywords.
- The tag has five keywords: LinkedIn account rentals, LinkedIn infrastructure, B2B outbound, cold email inboxes, and high-trust LinkedIn profiles.

## [x] Service-focused homepage structure
- Remove the Book a demo section.
- Update the Resources section with our core services details and add some brief details about Inbstack.
- Remove the Product section.
- Make sure that all things on the page are based on our core services.
- Remove navigation and footer links for sections that are removed; do not leave links pointing to missing sections.

## [x] Interactive core-service slider
- Present the three Inbstack core services in an attractive, responsive slider inspired by the supplied campaign-dashboard/profile visual, without making the offerings appear to be a product software dashboard.
- Include clear previous/next controls and direct slide indicators; support touch swiping and keyboard-accessible controls.
- Keep all service descriptions and details aligned with LinkedIn rentals, standalone Microsoft inbox packs, and human-grown LinkedIn profiles; do not alter existing prices or service terms.
- Preserve the established Inbstack warm-neutral and violet brand styling and keep the layout usable on desktop and mobile.

## [x] Custom-location LinkedIn profile inquiry
- Provide an inquiry modal/form for customers interested in custom location-based LinkedIn profile orders.
- Use the supplied WhatsApp Business number +855969653035; prepare a WhatsApp chat link with the customer’s inquiry details.
- Include the preferred country or region and profile tier (100+, 300+, or 500+ connections), with optional name and additional details.
- Explain that support confirms availability and requirements before an order is placed.
- Let the customer review and choose to continue to WhatsApp; do not send an inquiry automatically.

## [ ] LinkedIn account selector page — in progress
- The “Rent LinkedIn account” CTA opens a new account-selection page.
- Present European and American account choices with the displayed rates of $160 per European account and $200 per American account.
- Describe the account and IP as located in Europe or the United States, respectively, and state that each account works only on prospects in the matching region.
- Let customers select account quantities with sliders and plus/minus controls; show selected counts and a live USD monthly total.
- Follow the reference’s split layout, benefits sidebar, account cards, and three-step progress indicator while using Inbstack branding.
- Keep the account-selection page and its controls responsive on mobile as well as desktop.
