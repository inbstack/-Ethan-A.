import { useEffect, useRef, useState, type FormEvent, type KeyboardEvent } from "react";
import {
  ArrowRight,
  ArrowUpRight,
  BarChart3,
  Check,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  CircleCheck,
  Linkedin,
  MapPin,
  Menu,
  MessageCircle,
  ShieldCheck,
  Sparkles,
  Target,
  UsersRound,
  X,
} from "lucide-react";

type AvatarProps = {
  initials: string;
  tone?: "lilac" | "blue" | "peach" | "green" | "rose" | "ink";
  size?: "small" | "medium" | "large";
};

function Avatar({ initials, tone = "lilac", size = "medium" }: AvatarProps) {
  return (
    <span className={`avatar avatar--${tone} avatar--${size}`} aria-hidden="true">
      {initials}
    </span>
  );
}

function BrandMark() {
  return (
    <span className="brand-mark" aria-hidden="true">
      <span className="brand-mark__layer brand-mark__layer--back" />
      <span className="brand-mark__layer brand-mark__layer--middle" />
      <span className="brand-mark__layer brand-mark__layer--front" />
    </span>
  );
}

const navItems = [
  { label: "Core services", href: "#services" },
  { label: "How it works", href: "#how-it-works" },
  { label: "Pricing", href: "#pricing" },
  { label: "Resources", href: "#resources" },
];

const segmentNames = [
  "Agencies",
  "Lead gen teams",
  "Recruiters",
  "Growth teams",
  "Sales teams",
  "B2B operators",
];

const tickerItems = [
  "LinkedIn rentals with verified proxy configurations",
  "3+ year old Microsoft inbox packs",
  "Human-grown LinkedIn profiles",
  "14-day replacement guarantee",
];

const coreServices = [
  {
    number: "01",
    eyebrow: "SIMPLE MONTHLY PLANS",
    kind: "LINKEDIN RENTALS",
    title: "LinkedIn Rentals Service",
    description: "A focused monthly rental plan with verified proxy configurations and a 14-day replacement guarantee.",
    icon: Linkedin,
    highlights: ["Verified proxy configurations", "14-day replacement guarantee", "Start focused, scale with confidence"],
    visualLabel: "LINKEDIN RENTAL",
    visualHeading: "Your outreach, on steadier ground.",
    visualDetail: "Dedicated account access",
    metric: "from $149 / month",
    tone: "linkedin",
  },
  {
    number: "02",
    eyebrow: "STANDALONE INBOX PACKS",
    kind: "COLD EMAIL INFRASTRUCTURE",
    title: "Cold Email Infrastructure",
    description: "3+ year old Microsoft inboxes in packs of 5, 10, or 20. Build your email stack without adding a LinkedIn rental plan.",
    icon: MessageCircle,
    highlights: ["3+ year old Microsoft inboxes", "Standalone packs of 5, 10, or 20", "No LinkedIn rental plan required"],
    visualLabel: "MICROSOFT INBOX PACKS",
    visualHeading: "Add email infrastructure on its own.",
    visualDetail: "Choose a pack to fit your needs",
    metric: "from $49 / month",
    tone: "inbox",
  },
  {
    number: "03",
    eyebrow: "HUMAN-GROWN PROFILES",
    kind: "HIGH-TRUST LINKEDIN PROFILES",
    title: "High-Trust LinkedIn Profiles",
    description: "Manually grown LinkedIn profiles built through patient, human-led activity—not shortcuts.",
    icon: UsersRound,
    highlights: ["100+, 300+, and 500+ connection tiers", "Patient, human-led activity", "Custom location requests reviewed by support"],
    visualLabel: "HUMAN-LED PROFILE GROWTH",
    visualHeading: "Built patiently, one connection at a time.",
    visualDetail: "Custom country or region requests",
    metric: "100+ · 300+ · 500+ connections",
    tone: "profiles",
  },
];

export default function Home() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [activeService, setActiveService] = useState(0);
  const [profileOrderOpen, setProfileOrderOpen] = useState(false);
  const [selectedProfileTier, setSelectedProfileTier] = useState("");
  const [whatsappHref, setWhatsappHref] = useState("");
  const touchStartX = useRef<number | null>(null);
  const profileOrderDialogRef = useRef<HTMLDialogElement>(null);
  const profileOrderFormRef = useRef<HTMLFormElement>(null);

  useEffect(() => {
    const dialog = profileOrderDialogRef.current;
    if (!dialog) return;
    if (profileOrderOpen && !dialog.open) dialog.showModal();
    if (!profileOrderOpen && dialog.open) dialog.close();
  }, [profileOrderOpen]);

  const openProfileOrder = (tier = "") => {
    profileOrderFormRef.current?.reset();
    setSelectedProfileTier(tier);
    setWhatsappHref("");
    setProfileOrderOpen(true);
  };

  const handleProfileOrderSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const formData = new FormData(event.currentTarget);
    const name = String(formData.get("name") ?? "").trim();
    const region = String(formData.get("region") ?? "").trim();
    const tier = String(formData.get("tier") ?? "").trim();
    const details = String(formData.get("details") ?? "").trim();
    const message = [
      "Hello Inbstack, I’m interested in a custom-location LinkedIn profile order.",
      `Preferred country or region: ${region}`,
      `Profile tier: ${tier}`,
      ...(name ? [`Name: ${name}`] : []),
      ...(details ? [`Additional details: ${details}`] : []),
      "Please confirm availability and requirements before I place an order.",
    ].join("\n");
    setWhatsappHref(`https://wa.me/855969653035?text=${encodeURIComponent(message)}`);
  };

  const showService = (index: number) => {
    setActiveService((index + coreServices.length) % coreServices.length);
  };

  const handleSliderKeyDown = (event: KeyboardEvent<HTMLElement>) => {
    if (event.key === "ArrowLeft") {
      event.preventDefault();
      showService(activeService - 1);
    }
    if (event.key === "ArrowRight") {
      event.preventDefault();
      showService(activeService + 1);
    }
  };

  const activeServiceData = coreServices[activeService];
  const ActiveServiceIcon = activeServiceData.icon;

  return (
    <div className="site-shell">
      <header className="site-header">
        <nav className="site-nav" aria-label="Main navigation">
          <a className="brand" href="#top" aria-label="Inbstack home" onClick={() => setMenuOpen(false)}>
            <BrandMark />
            <span className="brand-word">inbstack<span className="brand-trademark">™</span></span>
          </a>

          <button
            className="mobile-menu-toggle"
            type="button"
            aria-label={menuOpen ? "Close navigation menu" : "Open navigation menu"}
            aria-expanded={menuOpen}
            onClick={() => setMenuOpen((open) => !open)}
          >
            {menuOpen ? <X size={19} /> : <Menu size={19} />}
          </button>

          <div className={`nav-links${menuOpen ? " nav-links--open" : ""}`}>
            {navItems.map((item) => (
              <a key={item.label} href={item.href} onClick={() => setMenuOpen(false)}>
                {item.label}
                {(item.label === "How it works" || item.label === "Resources") && (
                  <ChevronDown size={12} strokeWidth={2.2} aria-hidden="true" />
                )}
              </a>
            ))}
            <a className="nav-primary" href="#services" onClick={() => setMenuOpen(false)}>
              Rent LinkedIn account <ArrowRight size={14} aria-hidden="true" />
            </a>
          </div>
        </nav>
      </header>

      <main id="top">
        <section className="hero section-wrap" aria-labelledby="hero-title">
          <div className="hero-copy">
            <div className="eyebrow hero-eyebrow">
              <span className="eyebrow-mark"><Sparkles size={12} /></span>
              <span>Start focused, Scale your outreach safely.</span>
            </div>
            <h1 id="hero-title">
              Rent LinkedIn accounts.{" "}
              <span className="hero-highlight">Scale your outreach safely.</span>
            </h1>
            <p className="hero-positioning">Enterprise-Grade LinkedIn Infrastructure for B2B Outbound Teams.</p>
            <p className="hero-description">
              LinkedIn rentals, standalone cold-email inbox packs, and human-grown profiles for B2B outbound teams.
            </p>
            <div className="hero-actions">
              <a className="button button--primary" href="#services">
                Rent LinkedIn account <ArrowRight size={16} />
              </a>
            </div>
            <div className="hero-assurance">
              <span className="assurance-icon"><ShieldCheck size={15} /></span>
              <span>Built for consistent, team-led outbound</span>
              <span className="assurance-separator" />
              <span>Made to scale with intention</span>
            </div>
          </div>

          <div className="hero-visual" aria-label="Illustration of Inbstack's dedicated account and campaign workspace">
            <div className="visual-aura visual-aura--one" />
            <div className="visual-aura visual-aura--two" />
            <div className="visual-grid" />
            <div className="floating-note floating-note--top">
              <span className="note-icon note-icon--green"><CircleCheck size={15} /></span>
              <span><b>Account health</b><small>Ready for your team</small></span>
              <span className="note-live"><i />Live</span>
            </div>

            <div className="hero-profile hero-profile--back">
              <div className="mini-profile-cover mini-profile-cover--blue" />
              <div className="mini-profile-body">
                <Avatar initials="LB" tone="blue" size="medium" />
                <div className="profile-copy"><b>Lucas Becker</b><span>Head of Partnerships</span></div>
                <span className="profile-available"><i />Available</span>
              </div>
            </div>

            <div className="hero-dashboard">
              <div className="dashboard-topline">
                <div className="dashboard-brand"><span className="dashboard-brand-icon"><Linkedin size={13} /></span><span>OUTREACH OVERVIEW</span></div>
                <button className="dashboard-more" type="button" aria-label="Workspace options">•••</button>
              </div>
              <div className="dashboard-heading">
                <div><span className="dashboard-kicker">THIS WEEK</span><h2>Campaigns in motion</h2></div>
                <span className="dashboard-status"><i /> On track</span>
              </div>
              <div className="dashboard-metric-row">
                <div className="dashboard-metric"><strong>08</strong><span>Active accounts</span><small><span>+2</span> this month</small></div>
                <div className="dashboard-metric"><strong>12</strong><span>Campaign lanes</span><small><span className="purple-up">+3</span> in progress</small></div>
              </div>
              <div className="campaign-activity">
                <div className="activity-title"><span>CAMPAIGN ACTIVITY</span><span className="activity-range">This week <ChevronDown size={11} /></span></div>
                <div className="activity-chart" aria-hidden="true">
                  <div className="chart-guides"><i /><i /><i /></div>
                  <div className="chart-bars">
                    <i style={{ height: "42%" }} /><i style={{ height: "58%" }} /><i style={{ height: "48%" }} /><i style={{ height: "76%" }} /><i style={{ height: "64%" }} /><i style={{ height: "90%" }} /><i style={{ height: "72%" }} /><i style={{ height: "98%" }} />
                  </div>
                  <div className="chart-days"><span>M</span><span>T</span><span>W</span><span>T</span><span>F</span><span>M</span><span>T</span><span>W</span></div>
                </div>
              </div>
              <div className="dashboard-footer"><span className="stacked-avatars"><Avatar initials="AL" tone="peach" size="small" /><Avatar initials="MR" tone="blue" size="small" /><Avatar initials="JS" tone="green" size="small" /></span><span>Team workspace</span><span className="dashboard-link">View campaigns <ArrowUpRight size={12} /></span></div>
            </div>

            <div className="hero-profile hero-profile--front">
              <div className="profile-accent-line" />
              <Avatar initials="AL" tone="peach" size="large" />
              <div className="profile-main">
                <div className="profile-name-line"><b>Amelia Laurent</b><span className="profile-available"><i /> Available</span></div>
                <span>Partnerships Manager · Real Estate</span>
                <div className="profile-location"><span className="country-dot">●</span> France <span className="profile-dot">·</span><b>500+ connections</b></div>
              </div>
              <button type="button" className="connect-button"><UsersRound size={12} /> Connect</button>
            </div>

            <div className="floating-note floating-note--bottom">
              <span className="note-icon note-icon--purple"><Target size={15} /></span>
              <span><b>Built for parallel campaigns</b><small>Organized by market &amp; persona</small></span>
              <ArrowUpRight size={14} className="note-arrow" />
            </div>
            <div className="visual-caption"><span>01</span><span>One foundation. Room to scale.</span><i /></div>
          </div>
        </section>

        <section className="benefit-band" aria-label="Inbstack benefits">
          <div className="benefit-track">
            {[...tickerItems, ...tickerItems].map((item, index) => (
              <div className="benefit-item" key={`${item}-${index}`}>
                <span className="benefit-check"><Check size={13} /></span>{item}<span className="benefit-divider">/</span>
              </div>
            ))}
          </div>
        </section>

        <section className="services-section section-wrap" id="services" aria-labelledby="services-title">
          <div className="services-heading">
            <div>
              <span className="section-kicker"><span>01</span> CORE SERVICES</span>
              <h2 id="services-title">The right foundation<br /><span>for your next move.</span></h2>
            </div>
            <p>Choose from three focused services for LinkedIn outreach, cold email, and human-grown profiles.</p>
          </div>
          <div className="service-slider" role="region" aria-roledescription="carousel" aria-label="Inbstack core services">
            <button className="service-slider-arrow service-slider-arrow--previous" type="button" aria-label="Previous core service" onClick={() => showService(activeService - 1)}>
              <ChevronLeft size={20} />
            </button>
            <article
              className={`service-slide service-slide--${activeServiceData.tone}`}
              role="group"
              aria-roledescription="slide"
              aria-label={`${activeServiceData.number} of ${coreServices.length}: ${activeServiceData.title}`}
              tabIndex={0}
              onKeyDown={handleSliderKeyDown}
              onTouchStart={(event) => { touchStartX.current = event.touches[0]?.clientX ?? null; }}
              onTouchEnd={(event) => {
                if (touchStartX.current === null) return;
                const touchEndX = event.changedTouches[0]?.clientX;
                if (touchEndX !== undefined) {
                  const distance = touchEndX - touchStartX.current;
                  if (Math.abs(distance) > 48) showService(activeService + (distance < 0 ? 1 : -1));
                }
                touchStartX.current = null;
              }}
            >
              <div className="service-slide-copy" aria-live="polite">
                <div className="service-slide-topline"><span className="service-number">{activeServiceData.number}</span><span className="service-category">{activeServiceData.eyebrow}</span></div>
                <span className="service-kind">{activeServiceData.kind}</span>
                <h3>{activeServiceData.title}</h3>
                <p className="service-slide-description">{activeServiceData.description}</p>
                <ul className="service-slide-highlights">
                  {activeServiceData.highlights.map((item) => <li key={item}><CircleCheck size={15} />{item}</li>)}
                </ul>
                {activeService === 2 ? (
                  <button className="service-slide-link" type="button" aria-haspopup="dialog" aria-controls="profile-order-dialog" onClick={() => openProfileOrder()}>
                    Ask about a profile order<ArrowRight size={15} />
                  </button>
                ) : (
                  <a className="service-slide-link" href="#pricing">Explore service pricing<ArrowRight size={15} /></a>
                )}
              </div>
              <div className="service-slide-visual" aria-hidden="true">
                <div className="service-visual-orbit service-visual-orbit--outer" />
                <div className="service-visual-orbit service-visual-orbit--inner" />
                <div className="service-visual-card">
                  <div className="service-visual-top"><span className="service-visual-icon"><ActiveServiceIcon size={17} /></span><span className="service-visual-brand"><b>INBSTACK™</b><small>CORE SERVICE · {activeServiceData.number}</small></span></div>
                  <span className="service-visual-kicker">{activeServiceData.visualLabel}</span>
                  <h4>{activeServiceData.visualHeading}</h4>
                  <div className="service-visual-stat"><span className="service-visual-stat-icon"><ActiveServiceIcon size={17} /></span><span><b>{activeServiceData.visualDetail}</b><small>{activeServiceData.metric}</small></span><CircleCheck size={17} className="service-visual-check" /></div>
                  <div className="service-visual-footer"><span><i /><i /><i /></span>Inbstack™ · Core service</div>
                </div>
                <span className="service-float-note service-float-note--top"><CircleCheck size={15} /> Focused infrastructure</span>
                <span className="service-float-note service-float-note--bottom"><Sparkles size={15} /> Built around your needs</span>
              </div>
            </article>
            <button className="service-slider-arrow service-slider-arrow--next" type="button" aria-label="Next core service" onClick={() => showService(activeService + 1)}>
              <ChevronRight size={20} />
            </button>
            <div className="service-slider-controls">
              <span className="service-slider-count"><b>0{activeService + 1}</b> / 0{coreServices.length}</span>
              <div className="service-slider-dots" role="group" aria-label="Choose a core service slide">
                {coreServices.map((service, index) => (
                  <button key={service.number} type="button" aria-label={`Show ${service.title}`} aria-pressed={activeService === index} className={activeService === index ? "is-active" : ""} onClick={() => showService(index)} />
                ))}
              </div>
              <span className="service-slider-hint">SWIPE OR USE ARROWS</span>
            </div>
            <div className="service-location-note" id="location-orders">
              <MapPin size={17} aria-hidden="true" />
              <div><b>Custom location-based profile orders</b><span>Tell us your preferred country or region. Support will confirm availability and requirements before you order.</span></div>
              <button className="service-location-action" type="button" aria-haspopup="dialog" aria-controls="profile-order-dialog" onClick={() => openProfileOrder()}>
                Start an inquiry<ArrowRight size={14} />
              </button>
            </div>
          </div>
        </section>

        <section className="segment-section section-wrap" aria-labelledby="segment-title">
          <div className="segment-copy"><span className="section-kicker"><span>02</span> BUILT FOR YOUR MOTION</span><h2 id="segment-title">One infrastructure.<br /><span>Every kind of outbound team.</span></h2></div>
          <div className="segment-chips" aria-label="Teams served">
            {segmentNames.map((name, index) => <span key={name} className={`segment-chip${index === 0 || index === 4 ? " segment-chip--dark" : ""}`}>{name}<span>↗</span></span>)}
          </div>
        </section>

        <section className="how-section" id="how-it-works" aria-labelledby="how-title">
          <div className="section-wrap how-inner">
            <div className="how-intro"><span className="section-kicker section-kicker--light"><span>03</span> A SIMPLE WAY TO SCALE</span><h2 id="how-title">Choose what fits<br /><span>your outbound needs.</span></h2><p>Start with LinkedIn rentals, standalone cold-email inbox packs, or human-grown LinkedIn profiles—based on the service your team needs.</p><a href="#pricing" className="button button--light">Explore service plans <ArrowRight size={15} /></a></div>
            <div className="steps-list">
              <article className="step-item"><span className="step-number">01</span><div className="step-icon"><Target size={18} /></div><div><h3>Choose a core service</h3><p>Select LinkedIn rentals, cold email inboxes, or a human-grown profile tier.</p></div><ArrowUpRight size={16} className="step-arrow" /></article>
              <article className="step-item"><span className="step-number">02</span><div className="step-icon"><Linkedin size={17} /></div><div><h3>Confirm the details</h3><p>Choose a monthly plan or inbox pack. Support confirms custom profile-location availability and requirements.</p></div><ArrowUpRight size={16} className="step-arrow" /></article>
              <article className="step-item"><span className="step-number">03</span><div className="step-icon"><BarChart3 size={18} /></div><div><h3>Start with the right scope</h3><p>Choose a plan or pack for your needs; standalone inbox packs do not require a LinkedIn rental plan.</p></div><ArrowUpRight size={16} className="step-arrow" /></article>
            </div>
          </div>
        </section>

        <section className="service-pricing" id="pricing" aria-labelledby="pricing-title">
          <div className="section-wrap service-pricing-inner">
            <div className="service-pricing-heading">
              <div><span className="section-kicker section-kicker--light"><span>04</span> PLANS &amp; PRICING</span><h2 id="pricing-title">A plan for every<br /><span>part of your stack.</span></h2></div>
              <p>Choose a focused start across LinkedIn rentals, cold email inboxes, and human-grown profiles.</p>
            </div>

            <section className="price-service" aria-labelledby="email-pricing-title">
              <div className="price-service-heading">
                <div><span className="price-service-index">01 / STANDALONE INBOX PACKS</span><h3 id="email-pricing-title">Cold Email Infrastructure</h3><p>3+ year old Microsoft inboxes, available as standalone packs—no LinkedIn rental plan required.</p></div>
                <span className="price-service-badge"><MessageCircle size={13} /> STANDALONE</span>
              </div>
              <div className="price-card-grid">
                <article className="price-card">
                  <span className="price-card-label">STANDALONE PACK</span><h4>5 Microsoft inboxes</h4>
                  <div className="price-value">$49 <span>/ month</span></div>
                  <ul className="price-features"><li><Check size={13} /> 3+ year old Microsoft inboxes</li><li><Check size={13} /> No LinkedIn rental plan required</li></ul>
                  <a className="price-action" href="#services">See inbox service <ArrowUpRight size={14} /></a>
                </article>
                <article className="price-card price-card--highlight">
                  <span className="price-card-label">STANDALONE PACK</span><h4>10 Microsoft inboxes</h4>
                  <div className="price-value">$89 <span>/ month</span></div>
                  <ul className="price-features"><li><Check size={13} /> 3+ year old Microsoft inboxes</li><li><Check size={13} /> No LinkedIn rental plan required</li></ul>
                  <a className="price-action" href="#services">See inbox service <ArrowUpRight size={14} /></a>
                </article>
                <article className="price-card">
                  <span className="price-card-label">STANDALONE PACK</span><h4>20 Microsoft inboxes</h4>
                  <div className="price-value">$159 <span>/ month</span></div>
                  <ul className="price-features"><li><Check size={13} /> 3+ year old Microsoft inboxes</li><li><Check size={13} /> No LinkedIn rental plan required</li></ul>
                  <a className="price-action" href="#services">See inbox service <ArrowUpRight size={14} /></a>
                </article>
              </div>
            </section>

            <section className="price-service" aria-labelledby="profile-pricing-title">
              <div className="price-service-heading">
                <div><span className="price-service-index">02 / HIGH-TRUST LINKEDIN PROFILES</span><h3 id="profile-pricing-title">Human-Grown Profile Tiers</h3><p>Manually grown through patient, human-led activity. Profile levels are organized by connection count.</p></div>
                <span className="price-service-badge"><UsersRound size={13} /> HUMAN-LED</span>
              </div>
              <div className="price-card-grid">
                <article className="price-card price-card--profile">
                  <span className="price-card-label">PROFILE TIER 01</span><h4>100+ connections</h4>
                  <div className="price-contact">Check availability with support</div>
                  <ul className="price-features"><li><Check size={13} /> High-trust LinkedIn profile</li><li><Check size={13} /> Patient, human-led activity</li></ul>
                  <button className="price-action price-action--inquiry" type="button" aria-haspopup="dialog" aria-controls="profile-order-dialog" onClick={() => openProfileOrder("100+ connections")}>Ask about this tier <ArrowUpRight size={14} /></button>
                </article>
                <article className="price-card price-card--profile price-card--highlight">
                  <span className="price-card-label">PROFILE TIER 02</span><h4>300+ connections</h4>
                  <div className="price-contact">Check availability with support</div>
                  <ul className="price-features"><li><Check size={13} /> High-trust LinkedIn profile</li><li><Check size={13} /> Patient, human-led activity</li></ul>
                  <button className="price-action price-action--inquiry" type="button" aria-haspopup="dialog" aria-controls="profile-order-dialog" onClick={() => openProfileOrder("300+ connections")}>Ask about this tier <ArrowUpRight size={14} /></button>
                </article>
                <article className="price-card price-card--profile">
                  <span className="price-card-label">PROFILE TIER 03</span><h4>500+ connections</h4>
                  <div className="price-contact">Check availability with support</div>
                  <ul className="price-features"><li><Check size={13} /> High-trust LinkedIn profile</li><li><Check size={13} /> Patient, human-led activity</li></ul>
                  <button className="price-action price-action--inquiry" type="button" aria-haspopup="dialog" aria-controls="profile-order-dialog" onClick={() => openProfileOrder("500+ connections")}>Ask about this tier <ArrowUpRight size={14} /></button>
                </article>
              </div>
              <p className="profile-pricing-note"><MapPin size={14} /> For custom locations, share your preferred country or region; support confirms availability and requirements before you order.</p>
            </section>

            <section className="price-service price-service--last" aria-labelledby="rental-pricing-title">
              <div className="price-service-heading">
                <div><span className="price-service-index">03 / SIMPLE MONTHLY PLANS</span><h3 id="rental-pricing-title">LinkedIn Rentals Service</h3><p>Start focused, Scale with confidence. Monthly rental plans with verified proxy configurations and a 14-day replacement guarantee.</p></div>
                <span className="price-service-badge"><Linkedin size={13} /> LINKEDIN RENTALS</span>
              </div>
              <div className="price-card-grid">
                <article className="price-card">
                  <span className="price-card-label">MONTHLY PLAN</span><h4>Launch</h4>
                  <div className="price-value">$149 <span>/ month</span></div>
                  <ul className="price-features"><li><Check size={13} /> Monthly LinkedIn rental</li><li><Check size={13} /> Verified proxy configuration</li><li><Check size={13} /> 14-day replacement guarantee</li></ul>
                  <a className="price-action" href="#services">See rental service <ArrowUpRight size={14} /></a>
                </article>
                <article className="price-card price-card--highlight">
                  <span className="price-card-label">MONTHLY PLAN</span><h4>Growth</h4>
                  <div className="price-value">$649 <span>/ month</span></div>
                  <ul className="price-features"><li><Check size={13} /> Monthly LinkedIn rental</li><li><Check size={13} /> Verified proxy configuration</li><li><Check size={13} /> 14-day replacement guarantee</li></ul>
                  <a className="price-action" href="#services">See rental service <ArrowUpRight size={14} /></a>
                </article>
                <article className="price-card">
                  <span className="price-card-label">MONTHLY PLAN</span><h4>Agency</h4>
                  <div className="price-value">$1,199 <span>/ month</span></div>
                  <ul className="price-features"><li><Check size={13} /> Monthly LinkedIn rental</li><li><Check size={13} /> Verified proxy configuration</li><li><Check size={13} /> 14-day replacement guarantee</li></ul>
                  <a className="price-action" href="#services">See rental service <ArrowUpRight size={14} /></a>
                </article>
              </div>
            </section>
          </div>
        </section>

        <section className="resources-section section-wrap" id="resources" aria-labelledby="resources-title">
          <div className="resources-heading">
            <span className="section-kicker"><span>05</span> RESOURCES</span>
            <h2 id="resources-title">Services for<br /><span>focused outreach.</span></h2>
            <p className="resources-intro">Inbstack™ provides enterprise-grade LinkedIn and cold-email infrastructure for B2B outbound teams. Start focused with the service your team needs, then scale at your own pace.</p>
          </div>
          <div className="resource-service-list">
            <article className="resource-service-item">
              <span className="resource-service-number">01</span>
              <div><h3>LinkedIn Rentals Service</h3><p>Monthly subscriptions with verified proxy configurations and a 14-day replacement guarantee.</p></div>
              <a href="#pricing" aria-label="View LinkedIn rental pricing"><ArrowUpRight size={16} /></a>
            </article>
            <article className="resource-service-item">
              <span className="resource-service-number">02</span>
              <div><h3>Cold Email Infrastructure</h3><p>3+ year old Microsoft inboxes in standalone packs of 5, 10, or 20—without a LinkedIn rental plan.</p></div>
              <a href="#pricing" aria-label="View cold email pack pricing"><ArrowUpRight size={16} /></a>
            </article>
            <article className="resource-service-item">
              <span className="resource-service-number">03</span>
              <div><h3>High-Trust LinkedIn Profiles</h3><p>Manually grown through patient, human-led activity. For custom locations, support confirms availability and requirements before ordering.</p></div>
              <a href="#location-orders" aria-label="Review custom profile order details"><ArrowUpRight size={16} /></a>
            </article>
          </div>
        </section>

      </main>

      <dialog
        id="profile-order-dialog"
        className="order-dialog"
        ref={profileOrderDialogRef}
        aria-labelledby="profile-order-title"
        aria-describedby="profile-order-description"
        onClose={() => setProfileOrderOpen(false)}
      >
        <div className="order-dialog-inner">
          <div className="order-dialog-heading">
            <div>
              <span className="order-dialog-eyebrow"><MapPin size={13} /> CUSTOM LOCATION ORDER</span>
              <h2 id="profile-order-title">Tell us where you need a profile.</h2>
            </div>
            <button className="order-dialog-close" type="button" aria-label="Close order inquiry" onClick={() => profileOrderDialogRef.current?.close()}><X size={18} /></button>
          </div>
          <p className="order-dialog-description" id="profile-order-description">
            Share a preferred country or region and profile tier. Support will confirm availability and requirements before you place an order.
          </p>
          <p className="order-dialog-contact"><MessageCircle size={15} /> WhatsApp Business: <strong>+855969653035</strong></p>
          <form ref={profileOrderFormRef} className="order-form" onSubmit={handleProfileOrderSubmit} onChange={() => setWhatsappHref("")}>
            <label className="order-field order-field--wide">
              <span>Preferred country or region <b aria-hidden="true">*</b></span>
              <input name="region" type="text" placeholder="For example, Cambodia" autoComplete="country-name" maxLength={120} required autoFocus />
            </label>
            <div className="order-form-row">
              <label className="order-field">
                <span>Profile tier <b aria-hidden="true">*</b></span>
                <select name="tier" value={selectedProfileTier} onChange={(event) => { setSelectedProfileTier(event.target.value); setWhatsappHref(""); }} required>
                  <option value="" disabled>Select a tier</option>
                  <option value="100+ connections">100+ connections</option>
                  <option value="300+ connections">300+ connections</option>
                  <option value="500+ connections">500+ connections</option>
                </select>
              </label>
              <label className="order-field">
                <span>Your name <small>(optional)</small></span>
                <input name="name" type="text" placeholder="Name" autoComplete="name" maxLength={80} />
              </label>
            </div>
            <label className="order-field order-field--wide">
              <span>Additional details <small>(optional)</small></span>
              <textarea name="details" placeholder="Anything support should know about your request?" maxLength={600} rows={3} />
            </label>
            <p className="order-dialog-privacy">Your message is not sent from this form. You’ll review and send it in WhatsApp.</p>
            <div className="order-form-actions">
              <button className="order-submit" type="submit">Prepare WhatsApp inquiry<ArrowRight size={15} /></button>
            </div>
          </form>
          {whatsappHref && (
            <div className="whatsapp-draft" role="status">
              <p>Your inquiry is ready. Continue to WhatsApp Business to review the draft and send it when you’re ready.</p>
              <a href={whatsappHref} target="_blank" rel="noopener noreferrer">Continue to WhatsApp<ArrowUpRight size={15} /></a>
            </div>
          )}
        </div>
      </dialog>

      <footer className="site-footer section-wrap">
        <a className="brand brand--footer" href="#top"><BrandMark /><span className="brand-word">inbstack<span className="brand-trademark">™</span></span></a>
        <span className="footer-tagline">Start focused, Scale your outreach safely.</span>
        <div className="footer-links"><a href="#services">Core services</a><a href="#how-it-works">How it works</a><a href="#pricing">Pricing</a><a href="#resources">Resources</a></div>
        <span className="footer-copy">© {new Date().getFullYear()} Inbstack™</span>
      </footer>
    </div>
  );
}
