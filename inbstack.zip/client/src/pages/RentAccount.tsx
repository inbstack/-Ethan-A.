import { useEffect, useState } from "react";
import {
  ArrowLeft,
  ArrowRight,
  BadgeCheck,
  Check,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  FileText,
  Headset,
  MapPin,
  Minus,
  Plus,
  ShieldCheck,
  UsersRound,
  Warmth,
} from "lucide-react";
import { Link } from "wouter";

type AccountRegion = "europe" | "america";

type AccountOption = {
  id: AccountRegion;
  title: string;
  flag: string;
  price: number;
  location: string;
  prospects: string;
};

const accountOptions: AccountOption[] = [
  {
    id: "europe",
    title: "European Account",
    flag: "🇪🇺",
    price: 160,
    location: "Europe",
    prospects: "European",
  },
  {
    id: "america",
    title: "American Account",
    flag: "🇺🇸",
    price: 200,
    location: "United States",
    prospects: "American",
  },
];

const inboxPacks = [
  { inboxes: 5, price: 49 },
  { inboxes: 10, price: 89 },
  { inboxes: 20, price: 159 },
];

const benefits = [
  { icon: UsersRound, label: "+500 connections" },
  { icon: FileText, label: "Invoices available" },
  { icon: ShieldCheck, label: "3 months of warmup" },
  { icon: Headset, label: "Responsive customer service" },
  { icon: BadgeCheck, label: "No commitment" },
  { icon: Check, label: "Pro quality accounts" },
];

const steps = ["Add subscriptions", "Choose Addons", "Summary"];
const formatUsd = (amount: number) => `$${amount.toLocaleString("en-US")}`;
const clampQuantity = (quantity: number) =>
  Number.isFinite(quantity) ? Math.max(0, Math.min(100, Math.floor(quantity))) : 0;

export default function RentAccount() {
  const [step, setStep] = useState(1);
  const [quantities, setQuantities] = useState<Record<AccountRegion, number>>({
    europe: 0,
    america: 0,
  });
  const [selectedInboxPack, setSelectedInboxPack] = useState<number | null>(null);
  const [selectionError, setSelectionError] = useState("");

  useEffect(() => {
    const previousTitle = document.title;
    document.title = "Rent a LinkedIn account | Inbstack™";
    return () => {
      document.title = previousTitle;
    };
  }, []);

  const selectedAccountCount = quantities.europe + quantities.america;
  const accountMonthlyTotal =
    quantities.europe * accountOptions[0].price + quantities.america * accountOptions[1].price;
  const inboxPack = inboxPacks.find((pack) => pack.inboxes === selectedInboxPack);
  const inboxMonthlyTotal = inboxPack?.price ?? 0;
  const monthlyTotal = accountMonthlyTotal + inboxMonthlyTotal;

  const updateQuantity = (region: AccountRegion, quantity: number) => {
    setSelectionError("");
    setQuantities((current) => ({ ...current, [region]: clampQuantity(quantity) }));
  };

  const advanceStep = () => {
    if (step === 1 && selectedAccountCount === 0) {
      setSelectionError("Select at least one account to continue.");
      return;
    }
    setSelectionError("");
    setStep((current) => Math.min(3, current + 1));
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const goBack = () => {
    setSelectionError("");
    setStep((current) => Math.max(1, current - 1));
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const orderMessage = [
    "Hello Inbstack, I’d like to ask about a LinkedIn account subscription.",
    `European accounts: ${quantities.europe} × ${formatUsd(accountOptions[0].price)} / month`,
    `American accounts: ${quantities.america} × ${formatUsd(accountOptions[1].price)} / month`,
    `Cold Email Infrastructure pack: ${inboxPack ? `${inboxPack.inboxes} inboxes — ${formatUsd(inboxPack.price)} / month` : "None selected"}`,
    `Estimated monthly total: ${formatUsd(monthlyTotal)}`,
    "Please confirm availability and next steps before I place an order.",
  ].join("\n");
  const whatsappHref = `https://wa.me/855969653035?text=${encodeURIComponent(orderMessage)}`;

  return (
    <div className="rent-account-page">
      <aside className="rent-sidebar" aria-label="Subscription information">
        <Link href="/" className="rent-brand" aria-label="Inbstack home">
          <span className="rent-brand-mark" aria-hidden="true"><i /><i /><i /></span>
          <span>inbstack<span className="rent-brand-trademark">™</span></span>
        </Link>

        <div className="rent-sidebar-intro">
          <span className="rent-sidebar-eyebrow">LINKEDIN ACCOUNT RENTALS</span>
          <h1>Subscribe to a LinkedIn account ready for automation in a few clicks.</h1>
          <p>Choose a region, set your account quantity, and review your monthly estimate.</p>
        </div>

        <ul className="rent-benefit-list">
          {benefits.map(({ icon: BenefitIcon, label }) => (
            <li key={label}><BenefitIcon size={16} aria-hidden="true" /><span>{label}</span></li>
          ))}
        </ul>

        <nav className="rent-stepper" aria-label="Subscription progress">
          {steps.map((label, index) => {
            const stepNumber = index + 1;
            const isComplete = stepNumber < step;
            const isCurrent = stepNumber === step;
            return (
              <div className={`rent-step${isCurrent ? " is-current" : ""}${isComplete ? " is-complete" : ""}`} key={label}>
                {index > 0 && <span className="rent-step-line" aria-hidden="true" />}
                <button
                  type="button"
                  aria-current={isCurrent ? "step" : undefined}
                  aria-label={`Step ${stepNumber}: ${label}`}
                  disabled={stepNumber > step}
                  onClick={() => {
                    if (stepNumber < step) {
                      setStep(stepNumber);
                      setSelectionError("");
                    }
                  }}
                >
                  <span className="rent-step-number">0{stepNumber}</span>
                  <span className="rent-step-label">{label}</span>
                </button>
              </div>
            );
          })}
        </nav>

        <a className="rent-support-link" href="https://wa.me/855969653035" target="_blank" rel="noopener noreferrer">
          <span>Questions about your options?</span><b>Talk to Inbstack support <ArrowRight size={14} /></b>
        </a>
      </aside>

      <main className="rent-main">
        <header className="rent-toolbar">
          {step === 1 ? (
            <Link href="/" className="rent-back-link"><ChevronLeft size={17} /> Back</Link>
          ) : (
            <button className="rent-back-link" type="button" onClick={goBack}><ChevronLeft size={17} /> Back</button>
          )}
          <div className="rent-toolbar-tools" aria-label="Page settings">
            <span className="rent-tool-pill"><b>$</b> USD <ChevronDown size={14} /></span>
            <span className="rent-tool-pill rent-language-pill"><span aria-hidden="true">🇬🇧</span> English <ChevronDown size={14} /></span>
          </div>
        </header>

        {step === 1 && (
          <section className="rent-step-content" aria-labelledby="rent-step-title">
            <div className="rent-content-title-row">
              <div>
                <span className="rent-content-kicker">STEP 01 / ADD SUBSCRIPTIONS</span>
                <h2 id="rent-step-title">Choose the type of account</h2>
                <p>Select one or both regions. Each account is priced per month.</p>
              </div>
              <span className="rent-availability"><i /> Availability confirmed by support</span>
            </div>

            <div className="rent-account-grid">
              {accountOptions.map((account) => {
                const quantity = quantities[account.id];
                const regionalMonthlyTotal = quantity * account.price;
                return (
                  <article className={`rent-account-card${quantity > 0 ? " is-selected" : ""}`} key={account.id}>
                    <div className="rent-account-card-heading">
                      <span className="rent-count-badge">{quantity}</span>
                      <h3>{account.title}</h3>
                      <span className="rent-country-flag" aria-label={account.location}>{account.flag}</span>
                    </div>

                    <div className="rent-account-prices">
                      <span className="rent-selected-price">So <b>{formatUsd(regionalMonthlyTotal)}</b><small>/month</small></span>
                      <span className="rent-unit-price"><b>{formatUsd(account.price)}</b><small>/account / month</small></span>
                    </div>

                    <div className="rent-account-facts">
                      <p><Check size={14} aria-hidden="true" /> Account and IP located in <b>{account.location}</b></p>
                      <p><Check size={14} aria-hidden="true" /> Works only on <b>{account.prospects} prospects</b></p>
                    </div>

                    <div className="rent-quantity-area">
                      <div className="rent-quantity-heading">
                        <h4>Choose the number of accounts</h4>
                        <output htmlFor={`${account.id}-range`}>{quantity}</output>
                      </div>
                      <input
                        id={`${account.id}-range`}
                        className="rent-range-input"
                        type="range"
                        min="0"
                        max="50"
                        step="1"
                        value={Math.min(quantity, 50)}
                        aria-label={`Number of ${account.title.toLowerCase()}s`}
                        onChange={(event) => updateQuantity(account.id, Number(event.target.value))}
                      />
                      <div className="rent-range-ticks" aria-hidden="true"><span>1</span><span>10</span><span>20</span><span>30</span><span>40</span><span>50+</span></div>
                      <div className="rent-stepper-control">
                        <button type="button" aria-label={`Remove one ${account.title.toLowerCase()}`} disabled={quantity === 0} onClick={() => updateQuantity(account.id, quantity - 1)}><Minus size={15} /></button>
                        <input
                          type="number"
                          min="0"
                          max="100"
                          inputMode="numeric"
                          aria-label={`${account.title} quantity`}
                          value={quantity}
                          onChange={(event) => updateQuantity(account.id, Number(event.target.value))}
                        />
                        <button type="button" aria-label={`Add one ${account.title.toLowerCase()}`} onClick={() => updateQuantity(account.id, quantity + 1)}><Plus size={15} /></button>
                      </div>
                    </div>
                  </article>
                );
              })}
            </div>
          </section>
        )}

        {step === 2 && (
          <section className="rent-step-content rent-addon-step" aria-labelledby="rent-step-title">
            <div className="rent-content-title-row">
              <div>
                <span className="rent-content-kicker">STEP 02 / OPTIONAL SERVICES</span>
                <h2 id="rent-step-title">Choose add-ons</h2>
                <p>Add Cold Email Infrastructure if it fits your setup. It remains available as a standalone service.</p>
              </div>
              <span className="rent-optional-pill">OPTIONAL</span>
            </div>

            <fieldset className="rent-addon-fieldset">
              <legend>Cold Email Infrastructure</legend>
              <p className="rent-addon-description">Choose one Microsoft inbox pack, or continue without an add-on.</p>
              <div className="rent-addon-options">
                <label className={`rent-addon-option${selectedInboxPack === null ? " is-selected" : ""}`}>
                  <input type="radio" name="inbox-pack" checked={selectedInboxPack === null} onChange={() => setSelectedInboxPack(null)} />
                  <span className="rent-addon-option-copy"><b>No add-on</b><small>Continue with LinkedIn accounts only</small></span>
                  <span className="rent-addon-price">$0<small>/month</small></span>
                </label>
                {inboxPacks.map((pack) => (
                  <label className={`rent-addon-option${selectedInboxPack === pack.inboxes ? " is-selected" : ""}`} key={pack.inboxes}>
                    <input type="radio" name="inbox-pack" checked={selectedInboxPack === pack.inboxes} onChange={() => setSelectedInboxPack(pack.inboxes)} />
                    <span className="rent-addon-option-copy"><b>{pack.inboxes} Microsoft inboxes</b><small>3+ year old inboxes · standalone pack</small></span>
                    <span className="rent-addon-price">{formatUsd(pack.price)}<small>/month</small></span>
                  </label>
                ))}
              </div>
            </fieldset>
            <aside className="rent-addon-note"><ShieldCheck size={18} /><p>Inbox packs do not require a LinkedIn rental plan. This selection simply adds the pack to your monthly estimate.</p></aside>
          </section>
        )}

        {step === 3 && (
          <section className="rent-step-content rent-review-step" aria-labelledby="rent-step-title">
            <div className="rent-content-title-row">
              <div>
                <span className="rent-content-kicker">STEP 03 / SUMMARY</span>
                <h2 id="rent-step-title">Review your selection</h2>
                <p>Check your account mix and estimated monthly total before contacting support.</p>
              </div>
              <span className="rent-availability"><i /> No payment collected here</span>
            </div>

            <div className="rent-review-card">
              <div className="rent-review-heading"><span>YOUR SUBSCRIPTION</span><span>USD · MONTHLY ESTIMATE</span></div>
              {accountOptions.map((account) => {
                const quantity = quantities[account.id];
                return (
                  <div className="rent-review-line" key={account.id}>
                    <span><span className="rent-review-flag">{account.flag}</span><b>{account.title}</b><small>{quantity} × {formatUsd(account.price)} / account</small></span>
                    <b>{formatUsd(quantity * account.price)}<small>/mo</small></b>
                  </div>
                );
              })}
              <div className="rent-review-line">
                <span><span className="rent-review-icon"><FileText size={16} /></span><b>Cold Email Infrastructure</b><small>{inboxPack ? `${inboxPack.inboxes} Microsoft inboxes` : "No inbox pack selected"}</small></span>
                <b>{formatUsd(inboxMonthlyTotal)}<small>/mo</small></b>
              </div>
              <div className="rent-review-total"><span>Estimated total</span><b>{formatUsd(monthlyTotal)}<small>/month</small></b></div>
              <p className="rent-review-disclaimer">This is an estimate based on your current selection. Inbstack support will confirm availability and next steps.</p>
              <div className="rent-review-actions">
                <button type="button" className="rent-review-back" onClick={goBack}><ArrowLeft size={15} /> Back to add-ons</button>
                <a className="rent-whatsapp-button" href={whatsappHref} target="_blank" rel="noopener noreferrer"><span>Continue to WhatsApp</span><ArrowRight size={16} /></a>
              </div>
            </div>
          </section>
        )}

        {step < 3 && (
          <div className="rent-checkout-bar" aria-label="Subscription summary">
            <div className="rent-summary-copy">
              <b>Summary</b>
              <span>Number of selected accounts</span>
              <div className="rent-summary-counts">
                <span title="European accounts">🇪🇺 <b>{quantities.europe}</b></span>
                <span title="American accounts">🇺🇸 <b>{quantities.america}</b></span>
                {inboxPack && <span title="Selected inbox pack"><FileText size={13} /> <b>{inboxPack.inboxes}</b></span>}
              </div>
            </div>
            <div className="rent-summary-total"><span>Total</span><b>{formatUsd(monthlyTotal)}<small>/month</small></b></div>
            {selectionError && <p className="rent-selection-error" role="alert">{selectionError}</p>}
            <div className="rent-checkout-actions">
              {step === 2 && <button className="rent-continue-back" type="button" onClick={goBack}><ChevronLeft size={15} /> Back</button>}
              <button className="rent-continue-button" type="button" onClick={advanceStep}>{step === 1 ? "Continue" : "Review summary"}<ChevronRight size={17} /></button>
            </div>
          </div>
        )}

        <footer className="rent-page-footer"><span>INBSTACK™ · LINKEDIN ACCOUNT RENTALS</span><Link href="/">Return to Inbstack</Link></footer>
      </main>
    </div>
  );
}
